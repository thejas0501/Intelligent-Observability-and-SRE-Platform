import json
import boto3
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

cloudwatch = boto3.client('cloudwatch', region_name='ap-south-1')
sns = boto3.client('sns', region_name='ap-south-1')

SNS_ARN = "arn:aws:sns:ap-south-1:615178205722:intelligent-observability-sre-anomaly-alerts"

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Parse SNS message
    for record in event.get('Records', []):
        message = json.loads(record['Sns']['Message'])
        
        alarm_name = message.get('AlarmName', 'Unknown')
        state = message.get('NewStateValue', 'Unknown')
        reason = message.get('NewStateReason', 'Unknown')
        timestamp = datetime.utcnow().isoformat()

        logger.info(f"Alarm: {alarm_name}, State: {state}, Reason: {reason}")

        if state == 'ALARM':
            # Auto-response: publish detailed alert
            alert_message = f"""
🚨 ANOMALY DETECTED - SRE Platform

Alarm: {alarm_name}
State: {state}
Time: {timestamp}
Reason: {reason}

Auto-diagnosis:
- Check /api/orders error rate (10% intentional chaos)
- Review Prometheus burn rate alerts
- Check Grafana RED dashboard

Dashboard: https://thejas2211.grafana.net
Prometheus: http://65.2.126.228:9090/alerts
            """

            sns.publish(
                TopicArn=SNS_ARN,
                Subject=f"🚨 SRE Anomaly: {alarm_name}",
                Message=alert_message
            )
            logger.info("Alert published to SNS")

            # Log anomaly metric
            cloudwatch.put_metric_data(
                Namespace='SREPlatform/Anomalies',
                MetricData=[{
                    'MetricName': 'AnomalyDetected',
                    'Value': 1,
                    'Unit': 'Count',
                    'Dimensions': [
                        {'Name': 'AlarmName', 'Value': alarm_name},
                        {'Name': 'Environment', 'Value': 'dev'}
                    ]
                }]
            )

    return {'statusCode': 200, 'body': 'Anomaly handled'}
